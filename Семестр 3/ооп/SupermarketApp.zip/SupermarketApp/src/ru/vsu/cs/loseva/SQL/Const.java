package ru.vsu.cs.loseva.SQL;

public class Const {
    public static final String PRODUCT_TABLE = "products";
    public static final String PRODUCT_NAME = "name";
    public static final String PRODUCT_CATEGORY = "category";
    public static final String PRODUCT_PRICE = "price";
    public static final String PRODUCTION_DATE = "date";
    public static final String EXPIRY_DATE = "expiredate";
    public static final String PRODUCT_QUANTITY = "quantity";
    public static final String PRODUCT_TYPE = "type";
}