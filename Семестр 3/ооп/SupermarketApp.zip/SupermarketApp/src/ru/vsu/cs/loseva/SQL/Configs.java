package ru.vsu.cs.loseva.SQL;

public class Configs {
    protected String dbHost = "localhost";
    protected String dbPort = "3306";
    protected String dbUser = "root";
    protected String dbPass = "rusliz1222!!!";
    protected String dbName = "supermarketdb";
}
